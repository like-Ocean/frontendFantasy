# Frontend Fantasy

Frontend Fantasy - визуальная новелла, которая помогает игроку выбрать карьеру в области frontend разработки. Игра рассказывает о выпускнике, который хочет стать frontend developer(ом).
 

### Ссылки:
 1. [YouGile - Наша доска с задачами](https://ru.yougile.com/team/3300a4a3d683/%D0%92%D0%B8%D0%B7%D1%83%D0%B0%D0%BB%D1%8C%D0%BD%D0%B0%D1%8F-%D0%BD%D0%BE%D0%B2%D0%B5%D0%BB%D0%BB%D0%B0)
 2. [Наш общий гугл диск ](https://drive.google.com/drive/folders/1G-MypVbuodpBIkmKJ93AYUa0HmLMhMb-)

### Участники проекта

 1. [Катя Березовская - тимлид](https://vk.com/itsme21)
 2. [Сергей Ильиных - аналитик](https://vk.com/un4g1vable)
 3. [Лида Гребёнкина - геймдизайнер/сценарист](https://vk.com/pyrica)
 4. [Данил Дрягин - дизайнер](https://vk.com/fikucb)